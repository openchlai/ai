# Documentation
API docs, research notes, and compliance information.

## Documentation Sections
- **api_docs/** - API documentation.
- **research/** - AI model research.
- **compliance/** - Security & privacy policies.
