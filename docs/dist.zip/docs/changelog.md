# Changelog

The change logs for our project are maintained separately. Please refer to the [Change Log Page](https://github.com/openchlsystem/OpenCHS-helpline/blob/main/07_Guides/changelog.md) for a detailed history of changes, updates, and bug fixes made to the system.